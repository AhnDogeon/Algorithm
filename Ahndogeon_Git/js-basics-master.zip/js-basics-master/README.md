# JS Basics

Repository for the JS-Basics Nomad Academy Course. Cloning a Productivity App with VanillaJS
